const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


mongoose.connect('mongodb://localhost:27017/mydatabase', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB connection error:', err));

const postSchema = new mongoose.Schema({
  title: String,
  content: String,
  created: { type: Date, default: Date.now }
});

const Post = mongoose.model('Post', postSchema);

// Routes
app.get('/', async (req, res) => {
  try {
    const posts = await Post.find().sort({ created: -1 }).limit(5);
    res.render('index', { posts });
  } catch (err) {
    console.error("Error fetching posts:", err);
    res.status(500).send('An error occurred while fetching posts.');
  }
});

app.get('/posts/:id', async (req, res) => {
  const requestedPostId = req.params.id;
  try {
    const post = await Post.findById(requestedPostId);
    if (!post) {
      return res.status(404).send('Post not found');
    }
    res.render('post', { post });
  } catch (err) {
    console.error("Error fetching post:", err);
    res.status(500).send('An error occurred while fetching the post.');
  }
});

app.get('/new', (req, res) => {
  res.render('newpost');
});

app.post('/newpost', async (req, res) => {
  const post = new Post({
    title: req.body.title,
    content: req.body.content
  });

  try {
    await post.save();
    res.redirect('/');
  } catch (err) {
    console.error("Error creating post:", err);
    res.status(500).send('An error occurred while creating the post.');
  }
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
